<div id="{{uc_id}}" class="uc-items-wrapper {{remote_parent.class}} {{uc_filtering_addclass}}" {{remote_parent.attributes|raw}} {{uc_filtering_attributes|raw}} role="list">
  {{put_items()}}
</div>