{{ ucfunc("put_docready_start") }}
		
  var objBullets = jQuery('#{{uc_id}}');
  var objItems = objBullets.find(".ue_item");
  var classActive = "ue_active";

  if(objBullets.hasClass("uc-remote-parent") == false)
      	return(false);

  /**
  * on keydown
  */
  function onKeydown(event){
    var objItem = jQuery(event.target);
    var key = event.key || event.keyCode;
    
    if(key == 'Enter' || key == 13 || key == ' ' || key == 32){
      objItems.removeClass(classActive);
      objItem.addClass(classActive);
    }
    
    if(key == 'Escape' || key == 27)
      objItems.removeClass(classActive);
  }

  objItems.on("keydown", function(event){onKeydown(event)});
    
  var objRemoteOptions = {
    class_items:"ue_item",
    class_active:"ue_active",
    selector_item_trigger:null,
    add_set_active_code:true
  };
    
  {{ucfunc("put_remote_parent_js","objBullets","objRemoteOptions")}}
    	
{{ ucfunc("put_docready_end") }}