<div class="ue_item {{item.item_repeater_class}}" role="listitem" tabindex="0">
  <div class="ue_item_vr_line"></div>
  <div class="ue_item_hr_line"></div>
  <div class="ue_item_icon">
    {% if item.graphic_element == "icon" %}{{item.icon_html|raw}}{% endif %}
    {% if item.graphic_element == "text" %}{{item.text|raw}}{% endif %}
    {% if item.graphic_element == "image" %}<img src="{{item.image}}" {{item.image_attributes|ucsafe|raw}}>{% endif %}
  </div>
  <div class="ue_item_spacer"></div>
  <div class="ue_item_content">
    {% if show_title == "true" %}<div class="ue_item_title">{{item.title|raw}}</div>{% endif %}
    {% if show_content == "true" %}<div class="ue_item_text">{{item.content|raw}}</div>{% endif %}
  </div>
</div>