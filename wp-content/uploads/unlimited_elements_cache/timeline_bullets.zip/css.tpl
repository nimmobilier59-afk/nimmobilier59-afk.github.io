#{{uc_id}} .ue_item{
  display:flex;
  position:relative;
}

#{{uc_id}} .ue_item_icon{ 
  display:flex;
  align-items:center;
  justify-content:center;
  flex-grow:0;
  flex-shrink:0;
  line-height:1em;
  overflow:hidden;
}

#{{uc_id}} .ue_item_icon img{
  object-fit: cover;
}

#{{uc_id}} .ue_item_icon svg{ 
  height:1em;
  width:1em;
}

#{{uc_id}} .ue_item_spacer{
  flex-grow:0;
  flex-shrink:0;
}

#{{uc_id}} .ue_item_hr_line{
  flex-grow:0;
  flex-shrink:0;
}

#{{uc_id}} .ue_item_vr_line{
  height:100%;
  position:absolute;
  flex-grow:0;
  flex-shrink:0;
}

#{{uc_id}} .ue_item_title, 
#{{uc_id}} .ue_item_text,
#{{uc_id}} .ue_item_icon{
  transition: all .3s ease-out;
}

.ue_item_title{
  font-size:21px;
}

#{{uc_id}}.uc-remote-parent .ue_item{
  cursor:pointer;
}