#{{uc_id}} .ue_item{
  display:flex;
}

#{{uc_id}} .ue_item .ue_item_icon_holder{
  display:flex;
  flex-direction:column
}

#{{uc_id}} .ue_item_icon{  
  flex-shrink:0;
  flex-grow:0;
  position:relative;
}

#{{uc_id}} .ue_item_content{
  flex-grow:1;
}

.ue_item_title{
  font-size:21px;
}

#{{uc_id}} .ue_item_icon .ue_icon_output_wrapper{
  line-height:1em;
}

#{{uc_id}} .ue_item_icon .ue_icon_output_wrapper svg{
  height:1em;
  width:1em;
}

#{{uc_id}} .ue_item_icon_line{
  height:100%;
  margin-left:auto;
  margin-right:auto;
}

#{{uc_id}}  .ue_item:last-child .ue_item_icon_line{
  display:none;
}

#{{uc_id}} .ue_item_icon i{
  position:absolute;
  top:50%;
  left:50%;
  transform: translate(-50%,-50%);
}

#{{uc_id}} .ue_item_icon > svg path{
 stroke-linecap: round;
}

#{{uc_id}} .ue_icon_output_wrapper svg{
  position:absolute;
  top:50%;
  left:50%;
  transform: translate(-50%,-50%);  
}