<div id="{{uc_id}}" class="uc-items-wrapper {{uc_filtering_addclass}}" {{uc_filtering_attributes|raw}} role="list">
  {{put_items()}}
</div>